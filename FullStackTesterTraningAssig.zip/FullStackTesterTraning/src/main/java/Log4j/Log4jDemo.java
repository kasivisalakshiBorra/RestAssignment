package Log4j;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Log4jDemo {

	public static void main(String[] args) throws InterruptedException {
		//To specify Properties location for log4j
		PropertyConfigurator.configure("C:\\Users\\KasiVisalakshiBorra\\Desktop\\Visala\\PracticeFullStack\\FullStackTesterTraning\\src\\log4j.properties");
		//Creating instance of logger
		Logger log=Logger.getLogger("devpinoyLogger");
		System.out.println("Hello Log4J");
		log.info("Hello Log4J from Logger as info");
		log.debug("Hello Log4J from Logger as Debug");
		System.setProperty("webdriver.driver.chrome", "C:\\Users\\KasiVisalakshiBorra\\Desktop\\Visala\\PracticeFullStack\\FullStackTesterTraning\\chromedriver.exe");
		//firefox-webdriver.gecko.driver
		//IE-IE
		WebDriver wd=new ChromeDriver(); 
		wd.get("https://www.google.com/");
		wd.manage().window().maximize();
		Thread.sleep(5000);
		// Extracting Navigated URL
		System.out.println("URL:" + wd.getCurrentUrl());
		// Extracting Title
		System.out.println("TITLE:" + wd.getTitle());
		log.info("TITLE info");
		log.debug("TITLE Debug");
		
	}

}