import org.testng.annotations.Test;

public class FirstTestNgClass {
@Test
	public void firstTestMethod()
	{
		System.out.println("Hello testNg");
	}
	
}
