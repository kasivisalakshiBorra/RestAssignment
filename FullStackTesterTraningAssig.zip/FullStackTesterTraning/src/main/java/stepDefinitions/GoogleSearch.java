package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GoogleSearch {
	
	WebDriver driver=new ChromeDriver();
	
	
	@Given("I want to lauch google.com")
	public void i_want_to_lauch_google_com() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		System.out.println("Lauch google");
		driver.manage().window().maximize();
		driver.get("https://www.google.com/");
		
		
		/*driver.findElement(By.name("q")).sendKeys("Selenium is Good"+Keys.ENTER);
		Thread.sleep(5000);
		*/
		
	}

	@When("I entered the text {string}")
	public void i_entered_the_text(String string)  {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		System.out.println("Enter the text "+string);
		WebElement element = driver.findElement(By.name("q"));
		element.click();
		element.clear();
		element.sendKeys(string+Keys.ENTER);
		//Thread.sleep(1000);
		
	}


	@Then("Click on the first link")
	public void click_on_the_first_link() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		System.out.println("##then");
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		Thread.sleep(5000);
		WebElement element = driver.findElement(By.partialLinkText("7 Science-Based Health Benefits of Selenium - Healthline"));
		executor.executeScript("arguments[0].click();", element);
		
		driver.close();
		
		
	}
	
	
}
