package Rest;

import static org.testng.Assert.assertEquals;

import org.apache.http.util.Asserts;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class FirstRestDemo {
	
	@Test
	public void restDemo() {
		System.out.println("Inside Rest");
		//1. Base URI
		RestAssured.baseURI="https://restful-booker.herokuapp.com/ping/";
		//2. Request Specification
		RequestSpecification httpReq=RestAssured.given();
		Response res=httpReq.request(Method.GET);
		//3. Reading Reponse--Parsing Repsonse
		String respBody=res.getBody().asString();
		//4. Validation
		System.out.println(respBody);
		//5.responcecode
		System.out.println(res.getStatusCode());
		assertEquals(respBody, "Created");
		
	}
}
