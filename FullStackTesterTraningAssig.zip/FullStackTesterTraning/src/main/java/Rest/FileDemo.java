package Rest;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class FileDemo {
	@Test
	public void restDemo() {
		System.out.println("Inside Rest");
		//File handling
		File jsonFile=new File("C:\\Users\\KasiVisalakshiBorra\\Desktop\\Visala\\PracticeFullStack\\FullStackTesterTraning\\src\\main\\java\\Pojo\\AuthPayload.json");
		////==================Approach 1====================
		//1. Base URI
		RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
		//2. Request Specification
		Header acceptHeader = new Header("Content-Type","application/json");
        RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(jsonFile);
		Response res=httpReq.request(Method.POST);
		res.getBody().prettyPrint();
		int sta=res.getStatusCode();
		System.out.println(sta);
	}
	
	
	//Cucumber
	@Test
	public void restDemoCucumber() {
		System.out.println("Inside Rest");
		//File handling
		File jsonFile=new File("C:\\Users\\KasiVisalakshiBorra\\Desktop\\Visala\\PracticeFullStack\\FullStackTesterTraning\\src\\main\\java\\Pojo\\AuthPayload.json");
		RestAssured.given()
							.baseUri("https://restful-booker.herokuapp.com/auth")
							.contentType(ContentType.JSON)
							.body("")
					.when()
							.post()
					.then()
							.assertThat()
								.statusCode(200);
		}
}
