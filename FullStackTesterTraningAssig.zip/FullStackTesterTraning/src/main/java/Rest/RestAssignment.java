package Rest;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payloads.AuthPayload;

public class RestAssignment {
	@Test(priority = 1)
	public void restTokenPost() {
		System.out.println("Inside Rest");
		//1. Base URI
		RestAssured.baseURI="http://rest-api.upskills.in/api/rest/oauth2/token/client_credentials";
		//2. Request Specification
		Map<String, String> mp=new HashMap<String,String>();
		mp.put("Content-Type", "application/json");
		mp.put("Authorization", "Basic c2hvcHBpbmdfb2F1dGhfY2xpZW50OnNob3BwaW5nX29hdXRoX3NlY3JldA==");
		mp.put("accept", "application/json");
		
        RequestSpecification httpReq=RestAssured.given().headers(mp);
		Response res=httpReq.request(Method.POST);
		res.getBody().prettyPrint();
		int sta=res.getStatusCode();
		System.out.println(sta);
	}
	
	@Test(priority = 2)
	public void restCartGet() {
		System.out.println("Inside restCartGet");
		//1. Base URI
		RestAssured.baseURI="http://rest-api.upskills.in/api/rest/cart";
		//2. Request Specification
		Map<String, String> mp=new HashMap<String,String>();
		mp.put("Content-Type", "application/json");
		mp.put("Authorization", "Bearer 29229ebda3892ed4256b7afc7890b9b0e785681f");
		mp.put("accept", "application/json");
		
        RequestSpecification httpReq=RestAssured.given().headers(mp);
		Response res=httpReq.request(Method.GET);
		res.getBody().prettyPrint();
		int sta=res.getStatusCode();
		System.out.println("restCartGet:"+sta);
	}
	
	@Test(priority = 3)
	public void restProductGet() {
		System.out.println("Inside restProductGet");
		//1. Base URI
		RestAssured.baseURI="http://rest-api.upskills.in/api/rest/products";
		//2. Request Specification
		Map<String, String> mp=new HashMap<String,String>();
		mp.put("Content-Type", "application/json");
		mp.put("Authorization", "Bearer 29229ebda3892ed4256b7afc7890b9b0e785681f");
		mp.put("accept", "application/json");
		
        RequestSpecification httpReq=RestAssured.given().headers(mp);
		Response res=httpReq.request(Method.GET);
		res.getBody().prettyPrint();
		int sta=res.getStatusCode();
		System.out.println("restProductGet:"+sta);
	}
	
	@Test(priority = 4)
	public void restProductSimpleGet() {
		System.out.println("Inside restProductSimpleGet");
		//1. Base URI
		RestAssured.baseURI="http://rest-api.upskills.in/api/rest/products/simple";
		//2. Request Specification
		Map<String, String> mp=new HashMap<String,String>();
		mp.put("Content-Type", "application/json");
		mp.put("Authorization", "Bearer 29229ebda3892ed4256b7afc7890b9b0e785681f");
		mp.put("accept", "application/json");
		
        RequestSpecification httpReq=RestAssured.given().headers(mp);
		Response res=httpReq.request(Method.GET);
		res.getBody().prettyPrint();
		int sta=res.getStatusCode();
		System.out.println("restProductSimpleGet:"+sta);
	}
	
	///api/rest/categories
	@Test(priority = 5)
	public void restCategoriesGet() {
		System.out.println("Inside restCategoriesGet");
		//1. Base URI
		RestAssured.baseURI="http://rest-api.upskills.in/api/rest/categories";
		//2. Request Specification
		Map<String, String> mp=new HashMap<String,String>();
		mp.put("Content-Type", "application/json");
		mp.put("Authorization", "Bearer 29229ebda3892ed4256b7afc7890b9b0e785681f");
		mp.put("accept", "application/json");
		
        RequestSpecification httpReq=RestAssured.given().headers(mp);
		Response res=httpReq.request(Method.GET);
		res.getBody().prettyPrint();
		int sta=res.getStatusCode();
		System.out.println("restCategoriesGet:"+sta);
	}
	
	
	
}
