package Rest;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class StringDemo {
	@Test
	public void restDemo() {
		System.out.println("Inside Rest");
		//File handling
		//File jsonFile=new File("C:\\Users\\HP\\Desktop\\IGNITE\\DEMO\\src\\main\\java\\restAssuredDemo\\AuthPayload.json");
		////==================Approach 1====================
		//1. Base URI
		String jsonFile="{\"username\" : \"admin\",\"password\" : \"password123\"}";
		RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
		//2. Request Specification
		Header acceptHeader = new Header("Content-Type","application/json");
        RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(jsonFile);
		Response res=httpReq.request(Method.POST);
		res.getBody().prettyPrint();
		int sta=res.getStatusCode();
		System.out.println(sta);
	}
}


