package Rest;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import payloads.AuthPayload;

public class Logging_Conditional {
	@Test
	public void logCookies() {
		System.out.println("##############6");
		System.out.println("Inside Rest");
		////==================Approach 1====================
		AuthPayload authObject=new AuthPayload("admin", "password123");
		//1. Base URI
		//RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
		//2. Request Specification
		//Header acceptHeader = new Header("Content-Type","application/json");
        ////RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(authObject);
		
		RestAssured.given()
		//logs only body details.
		.baseUri("https://restful-booker.herokuapp.com/auth")
		.contentType(ContentType.JSON)
		.body(authObject)
		.when()
			.post()
		.then()
		//.log().ifValidationFails().statusCode(400);
		.log().ifValidationFails(LogDetail.STATUS).statusCode(400);//If condition  fail it will log only status code
		
		
	}
}
