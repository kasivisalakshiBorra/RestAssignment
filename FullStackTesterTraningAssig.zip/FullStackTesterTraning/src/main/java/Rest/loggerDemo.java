package Rest;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import payloads.AuthPayload;

public class loggerDemo {
	@Test
	public void logAll() {
		System.out.println("Inside Rest");
		////==================Approach 1====================
		AuthPayload authObject=new AuthPayload("admin", "password123");
		//1. Base URI
		//RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
		//2. Request Specification
		//Header acceptHeader = new Header("Content-Type","application/json");
        ////RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(authObject);
		System.out.println("##############1");
		RestAssured.given()
		//logs all details.
		.log().all()
		.baseUri("https://restful-booker.herokuapp.com/auth")
		.contentType(ContentType.JSON).body(authObject)
		.when()
		.post().then()
		.assertThat()
		.statusCode(200);
		
	}
	
	@Test
	public void logBody() {
		System.out.println("##############2");
		System.out.println("Inside Rest");
		////==================Approach 1====================
		AuthPayload authObject=new AuthPayload("admin", "password123");
		//1. Base URI
		//RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
		//2. Request Specification
		//Header acceptHeader = new Header("Content-Type","application/json");
        ////RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(authObject);
		
		RestAssured.given()
		//logs only body details.
		.log().body()
		.baseUri("https://restful-booker.herokuapp.com/auth")
		.contentType(ContentType.JSON).body(authObject)
		.when()
		.post().then()
		.assertThat()
		.statusCode(200);
		
	}
	
	@Test
	public void logEverything() {
		System.out.println("##############3");
		System.out.println("Inside Rest");
		////==================Approach 1====================
		AuthPayload authObject=new AuthPayload("admin", "password123");
		//1. Base URI
		//RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
		//2. Request Specification
		//Header acceptHeader = new Header("Content-Type","application/json");
        ////RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(authObject);
		
		RestAssured.given()
		//logs only body details.
		.log().everything()
		.baseUri("https://restful-booker.herokuapp.com/auth")
		.contentType(ContentType.JSON).body(authObject)
		.when()
		.post().then()
		.assertThat()
		.statusCode(200);
		
	}
	
	@Test
	public void logHeaders() {
		System.out.println("##############4");
		System.out.println("Inside Rest");
		////==================Approach 1====================
		AuthPayload authObject=new AuthPayload("admin", "password123");
		//1. Base URI
		//RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
		//2. Request Specification
		//Header acceptHeader = new Header("Content-Type","application/json");
        ////RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(authObject);
		
		RestAssured.given()
		//logs only body details.
		.log().headers()
		.baseUri("https://restful-booker.herokuapp.com/auth")
		.contentType(ContentType.JSON).body(authObject)
		.when()
		.post().then()
		.assertThat()
		.statusCode(200);
		
	}
	
	@Test
	public void logSatus() {
		System.out.println("##############5");
		System.out.println("Inside Rest");
		////==================Approach 1====================
		AuthPayload authObject=new AuthPayload("admin", "password123");
		//1. Base URI
		//RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
		//2. Request Specification
		//Header acceptHeader = new Header("Content-Type","application/json");
        ////RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(authObject);
		
		RestAssured.given()
		//logs only body details.
		.log().headers()
		.baseUri("https://restful-booker.herokuapp.com/auth")
		.contentType(ContentType.JSON).body(authObject)
		.when()
		.post().then()
		.log().status()
		.assertThat()
		.statusCode(200);
		
	}
	
	@Test
	public void logCookies() {
		System.out.println("##############6");
		System.out.println("Inside Rest");
		////==================Approach 1====================
		AuthPayload authObject=new AuthPayload("admin", "password123");
		//1. Base URI
		//RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
		//2. Request Specification
		//Header acceptHeader = new Header("Content-Type","application/json");
        ////RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(authObject);
		
		RestAssured.given()
		//logs only body details.
		.baseUri("https://restful-booker.herokuapp.com/auth")
		.contentType(ContentType.JSON).body(authObject)
		.when()
		.post().then()
		.log().cookies()
		.assertThat()
		.statusCode(200);
		
	}

}
