package Rest;


import java.util.Date;
import com.fasterxml.jackson.annotation.JsonProperty;

public class BookingDates {
	@JsonProperty
	Date checkin;
	@JsonProperty
	Date checkout;
	public Date getCheckin() {
		return checkin;
	}
	public void setCheckin(Date checkin) {
		this.checkin = checkin;
	}
	public Date getCheckout() {
		return checkout;
	}
	public void setCheckout(Date checkout) {
		this.checkout = checkout;
	}
	
}


