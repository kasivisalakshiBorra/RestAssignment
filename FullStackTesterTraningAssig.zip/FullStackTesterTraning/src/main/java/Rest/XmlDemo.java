package Rest;

import java.io.File;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class XmlDemo {
	
	@Test
	public void restDemo() {
		System.out.println("Inside Rest");
		//File handling
		//system.get
		File xmlFile=new File("C:\\Users\\KasiVisalakshiBorra\\Desktop\\Visala\\PracticeFullStack\\FullStackTesterTraning\\src\\main\\java\\Pojo\\AuthPayload.xml");
		RestAssured.given()
							.baseUri("https://restful-booker.herokuapp.com/auth")
							.contentType(ContentType.XML)
							.body(xmlFile)
					.when()
							.post()
					.then()
							.assertThat()
								.statusCode(200);
		}
}

