package Rest;


import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import payloads.AuthPayload;

public class Deserilization {
	
	//way1:
	@Test
	public void restDemo() {
		System.out.println("Inside Rest");
		////==================Approach 1====================
		AuthPayload authObject=new AuthPayload("admin", "password123");
		//1. Base URI
		RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
		//2. Request Specification
		Header acceptHeader = new Header("Content-Type","application/json");
        RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(authObject);
		Response res=httpReq.request(Method.POST);
		res.getBody().prettyPrint();
	}
	
	//way2:
		@Test
		public void restDemoCucumber() {
			System.out.println("Inside Rest");
			////==================Approach 1====================
			AuthPayload authObject=new AuthPayload("admin", "password123");
			//1. Base URI
			//RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
			//2. Request Specification
			//Header acceptHeader = new Header("Content-Type","application/json");
	        ////RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(authObject);
			
			RestAssured.given().baseUri("https://restful-booker.herokuapp.com/auth")
			.contentType(ContentType.JSON).body(authObject)
			.when()
			.post().then()
			.assertThat()
			.statusCode(200);
			
		}
}

