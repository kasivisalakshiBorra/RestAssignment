package Rest;

import io.restassured.RestAssured;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payloads.AuthPayload;

public class UserDemo {

	public void userDemo() {
		
		System.out.println("Inside Rest");
		////==================Approach 1====================
		AuthPayload authObject=new AuthPayload("admin", "password123");
		//1. Base URI
		//RestAssured.baseURI="https://restful-booker.herokuapp.com/auth";
		//2. Request Specification
		//Header acceptHeader = new Header("Content-Type","application/json");
        ////RequestSpecification httpReq=RestAssured.given().header(acceptHeader).body(authObject);
		
		Response res = RestAssured.given()
		.baseUri("https://reqres.in/api/users?page=2")
		.contentType(ContentType.JSON)
		.body(authObject)
		.when()
			.post();
		//String xx = res.getBody().prettyPrint();
		System.out.println(res.getStatusCode());
		
		
	}
	
	
}
