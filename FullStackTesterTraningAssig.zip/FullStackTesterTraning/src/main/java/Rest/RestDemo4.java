package Rest;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestDemo4 {
	
	@Test
	public void restDemo() {
		System.out.println("Inside Rest");
		//1. Base URI
		RestAssured.baseURI="https://restful-booker.herokuapp.com/booking/1";
		//2. Request Specification
        RequestSpecification httpReq=RestAssured.given();
		Response res=httpReq.request(Method.GET);
		//3. Reading Reponse--Parsing Repsonse
		BookingResponse bookingResponse=res.as(BookingResponse.class);
		//De-Serialization PLAIN TEXT>> JAVA OBject
		System.out.println("FiRST NAME="+bookingResponse.getFirstname());
		System.out.println(bookingResponse.getLastname());
		//assertEquals("Jim",bookingResponse.getFirstname());
		System.out.println("booking responce:"+bookingResponse.totalprice);
		System.out.println("depositpaid:"+bookingResponse.depositpaid);
	}

}
