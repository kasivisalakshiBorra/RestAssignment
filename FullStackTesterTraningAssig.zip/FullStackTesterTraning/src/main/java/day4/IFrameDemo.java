package day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class IFrameDemo {

	public static void main(String[] args) throws InterruptedException {
		// Launching Chrome
		System.setProperty("webdriver.driver.chrome", "C:\\Users\\KasiVisalakshiBorra\\Desktop\\Visala\\PracticeFullStack\\FullStackTesterTraning\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		// Navigating to google
		wd.get("https://www.globalsqa.com/demo-site/frames-and-windows/#iFrame");
		Thread.sleep(5000);
		wd.switchTo().frame("globalSqa");
		wd.findElement(By.partialLinkText("Home")).click();
		Thread.sleep(5000);
		wd.close();
		
	}

}