////ALERTS

//http://demo.automationtesting.in/Alerts.html

package day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertsDemo {

	public static void main(String[] args) throws InterruptedException {
		// Launching Chrome
		System.setProperty("webdriver.driver.chrome", "C:\\Users\\KasiVisalakshiBorra\\Desktop\\Visala\\PracticeFullStack\\FullStackTesterTraning\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		// Navigating to google
		wd.get("http://demo.automationtesting.in/Alerts.html");
		Thread.sleep(5000);
		wd.findElement(By.xpath("//*[@class='btn btn-danger']")).click();
		wd.switchTo().alert().accept();
		Thread.sleep(5000);
		wd.findElement(By.partialLinkText("Alert with OK & Cancel")).click();
		wd.findElement(By.xpath("//*[@class='btn btn-primary']")).click();
		wd.switchTo().alert().accept();
		wd.findElement(By.xpath("//*[@class='btn btn-primary']")).click();
		wd.switchTo().alert().dismiss();
		Thread.sleep(5000);
		wd.findElement(By.partialLinkText("Alert with Textbox")).click();
		wd.findElement(By.xpath("//*[@class='btn btn-info']")).click();
		wd.switchTo().alert().sendKeys("test");
		wd.switchTo().alert().accept();
		wd.findElement(By.xpath("//*[@class='btn btn-info']")).click();
		wd.switchTo().alert().accept();
		
		wd.close();
		
	}

}